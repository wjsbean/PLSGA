GAplsM <- function(phe,mrk,nAllel,ncomp=8,popSize=10,
									 pmut=0.1,pcross=0.5,freqb=20,evaluat=20,runs=200)
{
	maxvar <- 40
	phe <- as.matrix(phe)
	ynr <- nrow(phe)
	xnr <- nrow(mrk)
	if (ncol(mrk)<xnr){
		mrk <- as.matrix(t(mrk))
		xnr <- nrow(mrk)
		}
	if(ynr!=xnr){
		stop("The number of rows in var mrk and phe are difference!")
		}
	nmrk <- length(nAllel)
	cat("There are ",nmrk," marks!\n",sep="")
	
	if (floor(evaluat/100)==evaluat/100){
		endb="N"
		}
	else {
		endb="Y"
		}
	
	obj.pls <- plsreg_GA(mrk,phe,ncomp=ncomp)
	maxcomp <- obj.pls$Best
	
	slcted <- matrix(0,nrow=1,ncol=nmrk)
	Result<-NULL
	for(rep in 1:runs){
		cat("The",rep,"th replication\n",sep="")
		slcted <- matrix(c(slcted,0),nrow=1)
		lib <- c()
		libb <- c()
		nextb <- freqb
		
		# Generation of the GA population
		obj.init <- InitPopGA(phe,mrk,popSize,nAllel,ncomp=maxcomp)
		Indis <- obj.init$pop
		resp <- obj.init$resp
		comp <- obj.init$comp
		numvar <- obj.init$numvar
		lib <- obj.init$lib
		cc <- obj.init$index
		maxrisp <- resp[1]
		print("*****")
		cc0=0
		th<-1
		while(cc0<evaluat & th==1){
			#if (cc-tt==1){
			#	cat("The",cc,"th generation in",rep,"th replication\n",sep="")
			#}
			#cat("The ",cc,"th iter\n",sep="")
			# Selectiong, Crossover and mutation of parents
			obj.select <- select(Indis,resp)
			p<- obj.select$parent
			p <- cross(p,pcross)
			p <- mutation(p,pmut)
	
			# Evaluation of the offspring
			for (i in 1:2){
				den <- 0
				varID <- which(p[i,]!=0)
				sumvar <- length(varID)
				if(sumvar==0 | sumvar>maxvar){
					den <- 1
					} 
				if (den==0){
					den <- checktw(cc,lib,p[i,])
					}
				if (den==0){
					cc0 <- cc0+1
					cat("The ",cc0,"th generation in ",rep,"th replication\n",sep="")
					temp <- matrix(as.logical(rep(p[i,],nAllel)),nrow=1)
					Gmrk <- mrk[,temp]
					obj.pls <- plsreg_GA(Gmrk,phe,ncomp=maxcomp)
					fac <- obj.pls$Best
					risp <- obj.pls$expvarcv
					lib <- rbind(p[i,],lib)
					if (risp<maxrisp){
						maxrisp <- risp
						}
					if (risp<resp[popSize]){
						obj.upt <- updt(Indis,popSize,p[i,],resp,comp,numvar,risp,fac,varID)
						Indis <- obj.upt$Indis
						resp <- obj.upt$resp
						comp <- obj.upt$comp
						numvar <- obj.upt$numvar
						}
					}
				}

			if (cc0>=nextb){
				nextb <- nextb+freqb
				obj.back <- backw(Indis,resp,nAllel,numvar,cc0,mrk,phe,maxcomp,maxrisp,libb)
				nc <- obj.back$nc
				rispmax <- obj.back$rispmax
				compmax <- obj.back$compmax
				cc1 <- obj.back$cc
				maxrisp <- obj.back$maxrisp
				libb <- obj.back$libb
				if (length(nc)!=0){
					obj.upt <- updt(Indis,popSize,nc,resp,comp,numvar,rispmax,compmax,which(nc!=0))
					Indis <- obj.upt$Indis
					resp <- obj.upt$resp
					comp <- obj.upt$comp
					numvar <- obj.upt$numvar
					}
				}
			kk<-length(which(resp!=0))
			if (kk<length(resp)*0.05) th<-0
		}
		if (endb=="Y"){
			obj.back <- backw(Indis,resp,nAllel,numvar,cc0,mrk,phe,maxcomp,maxrisp,libb)
			nc <- obj.back$nc
			rispmax <- obj.back$rispmax
			compmax<- obj.back$compmax
			cc <- obj.back$cc
			maxrisp <- obj.back$maxrisp
			libb <- obj.back$libb
			if (length(nc)!=0){
				obj.upt <- updt(Indis,popSize,nc,resp,comp,numvar,rispmax,compmax,which(nc!=0))
				Indis <- obj.upt$Indis
				resp <- obj.upt$resp
				comp <- obj.upt$comp
				numvar <- obj.upt$numvar
				}
			}
		Result<-rbind(Result,matrix(colSums(Indis),nrow=1))
		slcted <- slcted[1:nmrk]+Indis[1,]
	}
	list(mrk.slcted=slcted,sindis=Indis,colsum=Result)
}

F1Construct<-function(mrk,pid){
	
	#p1:In NCII design table, arraging in rows
	#p2:In NCII design table, arraging in columns
	mrkID<-as.matrix(mrk[,1])
	Rname<-row.names(mrk)
	mrk<-mrk[,2:ncol(mrk)]
	nr<-nrow(mrk)
	np1<-sum(pid==1)
	np2<-sum(pid==2)
	nf1<-np1*np2
	p1<-mrk[,pid==1]
	p2<-mrk[,pid==2]
	
	result<-matrix(0,nrow=nr,ncol=nf1+1)
	id<-1
	for (i in 1:np2){
		for (j in 1:np1){
			id<-id+1
			result[,id]<-p1[,j]+p2[,i]
		}
	}
	result[,1]<-mrkID
	row.names(result)<-Rname
	
	id<-matrix(0,nrow=nr,ncol=1)
	lost<-NULL
	for (i in 1:max(mrkID)){
		ID<-mrkID==i
		if (sum(ID)!=1){
			id[ID]=1
			for (j in 2:(nf1+1)){
				if (sum(result[ID,j])==1){
					result[ID,j]<-result[ID,j]*2
				}
			}
		}
		else{
			lost<-append(lost,i)
		}
	}
	result<-result[as.logical(id),]
	list(mrk=result,lost=lost)
}

F1Scan<-function(mrk){

	LocCode<-mrk[,1]
	mrk<-mrk[,2:ncol(mrk)]
	nf1<-ncol(mrk)
	nloc<-max(LocCode)
	LC<-NULL
	F1ad<-matrix(0,nrow=1,ncol=nf1)
	for (i in 1:nloc){
		id<-LocCode==i
		if (sum(id)!=0){
			sloc<-mrk[id,]
			na<-nrow(sloc)
			aName<-matrix(paste("A","a",1:na,sep=""),ncol=1)
			a<-sloc*0.5
			nd<-(na*(na-1))/2
			d<-matrix(0,nrow=nd,ncol=nf1)
			dName<-matrix(0,nrow=nd,ncol=1)
		
			for (j in 1:nf1){
				if(any(sloc[,j]==1)){
					id<-which(sloc[,j]==1)
					ID<-id[1]/2*(2*na-id[1]+1)+id[2]-id[1]-na
					d[ID,j]<-1
					dName[ID]<-paste("D","a",id[1],"_","a",id[2],sep="")
				}
			}
			LC<-append(LC,matrix(rep(i,na+nd),ncol=1))
			ad<-rbind(a,d)
			row.names(ad)<-rbind(aName,dName)
			F1ad<-rbind(F1ad,ad)
		}
	}
	F1ad<-F1ad[-1,]
	index<-matrix(rowSums(F1ad)==0,ncol=1)
	F1ad<-F1ad[as.logical(index*(-1)+1),]
	LC<-LC[as.logical(index*(-1)+1)]
	nAllel<-NULL
	for (i in 1:nloc){
		id<-LC==i
		if (sum(id)!=0){
			nAllel<-append(nAllel,sum(id))
		}
	}
	list(mrk=F1ad,LocCode=LC,nAllel=nAllel)
}

M2Dummy<-function(mrk,nullM=-9){
	# M denote molecular massre
	# 2 denote to
	# Dummy denote Dummy variable
	
	mrkname<-mrk[2:nrow(mrk),1]
	ParentIndex<-mrk[1,2:ncol(mrk)]
	mrk<-mrk[2:nrow(mrk),2:ncol(mrk)]
	nr<-nrow(mrk) # The number of markers 
	nc<-ncol(mrk)  # The number of parents
	
	result<-matrix(0,nrow=1,ncol=nc)
	mrk.name<-matrix('MRK',nrow=1,ncol=1)
	ID<-matrix(0,nrow=1,ncol=1)
	
	for (i in 1:nr){
		temp<-mrk[i,]
		m<-sort(temp,index=T)
		id<-as.vector(order(temp))
		k<-0
		mNo<-matrix(0,nrow=2,ncol=1)
		while(k<=nc){
			k<-k+1
			if (k<=nc){
				nallel<-sum(m==as.numeric(m[k]))
				if (k==1){
					mNo[1]<-m[k]
					mNo[2]<-nallel
				}
				else{
					temp<-matrix(0,nrow=2,ncol=1)
					temp[1]<-m[k]
					temp[2]<-nallel
					mNo<-cbind(mNo,temp)
				}
				k<-k-1
				k<-k+nallel
			}
		}
		mNo<-as.matrix(mNo,nrow=2)
		nc1<-ncol(mNo)
		if (as.numeric(mNo[1,1])!=nullM){
			temp<-matrix(0,nrow=nc1,ncol=nc)
		}
		else{
			temp<-matrix(0,nrow=nc1-1,ncol=nc)
		}
		k<-0
		for (i1 in 1:nc1){
			if (as.numeric(mNo[1,1])!=nullM){
				if (i1==1){
					k1<-as.numeric(mNo[2,i1])
					k0<-drop(id[(k+1):k1])
					temp[i1,k0]<-1
				}
				else{
					k<-k+as.numeric(mNo[2,i1-1])
					k1<-as.numeric(mNo[2,i1])
					k0<-drop(id[(k+1):(k+k1)])
					temp[i1,k0]<-1
				}
			}
			else{
				if (i1>1){
					k<-k+as.numeric(mNo[2,i1-1])
					k1<-as.numeric(mNo[2,i1])
					k0<-drop(id[(k+1):(k+k1)])
					temp[i1-1,k0]<-1
					#print(temp[i1-1,])
				}
			}
		}
		result<-rbind(result,temp)
		if (as.numeric(mNo[1,1])!=nullM){
			temp<-as.matrix(paste(mrkname[i],1:nc1,sep="."),ncol=1)
			tempid<-as.matrix(rep(i,nc1),ncol=1)
		}
		else{
			temp<-as.matrix(paste(mrkname[i],1:(nc1-1),sep="."),ncol=1)
			tempid<-as.matrix(rep(i,(nc1-1)),ncol=1)
		}
		mrk.name<-rbind(mrk.name,temp)
		ID<-rbind(ID,tempid)
	}
	result<-cbind(ID,result)
	rownames(result)<-mrk.name
	result<-result[-1,]
	list(mrk=result,pID=ParentIndex,mrkname=mrkname)
}

GEEst<-function(phe,mrkf1,mrkslcted,loccode,ncomp=5,scale.x=FALSE,scale.y=TRUE)
{
	nrep<-ncol(phe)
	nf1<-nrow(phe)
	id<-1:max(loccode)
	library(pls)
	jack.test<-matrix(0,nrow=1,ncol=7)
	parameter<-matrix(0,nrow=1,ncol=3)
	RMSEP<-matrix(0,nrow=1,ncol=2)
	#npc<-c()
	
	for (i in 1:nrep){
		#ncomp<-8
		IDs<-NULL
		cat("Repeat",i,"\n")
		temphe<-matrix(phe[,i],ncol=1)
		tempmrk<-NULL
		ID<-id[as.logical(mrkslcted[,i])]
		print(ID)
		n<-length(ID)
		for (j in 1:n){
			temp<-mrkf1[loccode==ID[j],]
			temp<-t(temp)
			tempmrk<-cbind(tempmrk,temp)
			IDs<-append(IDs,loccode[loccode==ID[j]])
		}
		pls.out<-PLSest(tempmrk,temphe,ncomp=ncomp,scale.x=scale.x,scale.y=scale.y)
		jacktest<-pls.out$jacktest
		temp1<-cbind(jacktest[[1]],jacktest[[2]],jacktest[[3]],jacktest[[4]],jacktest[[5]])
		code<-matrix(rep(i,length(IDs)),ncol=1)
		IDs<-matrix(IDs,ncol=1)
		temp1<-cbind(code,IDs,temp1)
		jack.test<-rbind(jack.test,temp1)
		paraEst<-pls.out$paraEst
		paraEst<-cbind(code,IDs,paraEst)
		parameter<-rbind(parameter,paraEst)
		rmsep<-pls.out$rmsep
		rmsep<-cbind(matrix(rep(i,nrow(rmsep)),ncol=1),rmsep)
		RMSEP<-rbind(RMSEP,rmsep)
	}
	list(jackknife=jack.test,paraEst=parameter,RMSEP=RMSEP)
}

Allel.Prob<-function(mrk,loccode,locus,paraEst){
	
	nmrk<-max(loccode)
	nlocus<-length(locus)
	prob<-matrix(0,1,1)
	pEid<-paraEst[,1]
	paraEst<-paraEst[,-1]
	var.locus<-matrix(0,nrow=nlocus,ncol=3)
	var.locus1<-NULL
	nrep<-ncol(as.matrix(paraEst))
	for (r in 1:nrep){
		for (i in 1:nlocus){
			ID<-loccode==locus[i]
			temp<-mrk[ID,]
			n<-nrow(temp)
			anote<-substr(noquote(row.names(temp)),1,1)
			na<-sum(anote=="A")
			a.prob<-matrix(rowSums(temp[1:na,]!=0)/sum(temp[1:na,]!=0),ncol=1)
			row.names(a.prob)<-rep(paste("Mrk",locus[i],sep=""),na)
			if (n>3){
				d.prob<-matrix(rowSums(temp[(na+1):n,]!=0)/sum(temp[(na+1):n,]!=0),ncol=1)
			}
			else{
				d.prob<-matrix(1,nrow=1,ncol=1)
			}
			row.names(d.prob)<-rep(paste("Mrk",locus[i],sep=""),n-na)
			prob<-rbind(prob,a.prob)
			prob<-rbind(prob,d.prob)
			temp1<-matrix(rbind(a.prob,d.prob),nrow=1)
			if (nrep==1){
				pEtemp<-matrix(paraEst[pEid==drop(locus[i])],ncol=1)
			}
			else{
				pEtemp<-matrix(paraEst[pEid==drop(locus[i]),r],ncol=1)
			}
			#print(pEtemp[(na+1):n])
			ss<-temp1%*%pEtemp^2-(temp1%*%pEtemp)^2
			ass<-t(a.prob)%*%(matrix(pEtemp[1:na],ncol=1))^2-(t(a.prob)%*%(matrix(pEtemp[1:na],ncol=1)))^2
			if (length(pEtemp[(na+1):n])!=1){
				dss<-t(d.prob)%*%(matrix(pEtemp[(na+1):n],ncol=1))^2-(t(d.prob)%*%(matrix(pEtemp[(na+1):n],ncol=1)))^2
			}
			else{
				dss<-pEtemp[(na+1):n]^2
			}
			var.locus[i,2]<-ass
			var.locus[i,3]<-dss
			var.locus[i,1]<-ass+dss
		}
		colnames(var.locus)<-c("A+D","A","D")
		var.locus1<-cbind(var.locus1,var.locus)
	}
	row.names(var.locus1)<-paste("Mrk",locus,sep="")
	var.locus<-var.locus1
	list(prob=prob,var.locus=var.locus)
}

AllelInLines<-function(mrk,lost=-9){
	
	# The function is used to identify parential material and the combination 
	# which carring the selected marker loci and corresponding alleles
	
	# mrk: Matrix of original allele, the names of column are parents. 
	#         The second row is the index of male parents and female parents respectively
	#         The row names is the marker names
	#         The value of the matrix is molecular weights of alleles at every locus
	
	# Author: Wang Jinshe
	# National Center for Soybean Improvement (NCSI), NJAU
	# NanJing, 210095, P. R. China
	# E-mail: wangjinshe@gmail.com
	# Corresponding Author: Gai Junyi
	# E-mail: sri@njau.edu.cn
	# -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-END-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
	
	# Construction of F1 design matrix
	md<-M2Dummy(mrk)
	f1<-F1Construct(md$mrk,md$pID)
	fs<-F1Scan(f1$mrk)
	
	nmrk<-max(fs$LocCode)
	id<-mrk[1,][-1]
	mrk<-mrk[-1,]
	if (!is.numeric(mrk[1,1])){
		rownames(mrk)<-mrk[,1]
		mrk<-mrk[,-1]
	}
	Result<-NULL
	for (i in 1:nmrk){
		tmp<-mrk[i,]
		# Index of allele
		id0<-id
		if (length(which(tmp==lost))!=0){
			ii<-which(tmp==lost)
			id0<-id[-ii]
			tmp<-tmp[-ii]
		}

		Line_name<-noquote(colnames(tmp))
		tmp1<-sort(unique(t(tmp)))
		nAllel<-length(tmp1)
		ID_Allel<-cbind(matrix(tmp1,ncol=1),matrix(1:nAllel,ncol=1))
		ID_Allel<-as.matrix(ID_Allel)
		
		# names of parential lines
		male_name<-Line_name[id0==1]
		female_name<-Line_name[id0==2]
		A1<-tmp[id0==1]
		A2<-tmp[id0==2]
		
		# 
		ttt<-fs$mrk[fs$LocCode==i,]
		F1RName<-rownames(ttt)[(nAllel+1):nrow(ttt)]
		nd<-nrow(ttt)-nAllel
		ID1<-NULL
		ID2<-NULL
		for (j in 1:nd){
			tmp2<-strsplit(F1RName[j],"_")
			tt<-noquote(tmp2[[1]][1])
			ID1<-append(ID1,substr(tt,3,nchar(tt)))
			tt<-noquote(tmp2[[1]][2])
			ID2<-append(ID2,substr(tt,2,nchar(tt)))
		}
		ID1<-as.numeric(ID1)
		ID2<-as.numeric(ID2)
		
		tmp3<-NULL
		for (k in 1:nAllel){
			ss<-tmp==ID_Allel[k,1]
			mm<-NULL			
			n<-length(which(as.numeric(ss)!=0))
			for (k1 in 1:n){
				mm<-paste(mm,Line_name[ss][k1],sep=",")
			}
			mm<-substr(noquote(mm),2,nchar(mm))
			#rownames(mm)<-paste("A",ID_Allel[k,1],sep="")
			tmp3<-rbind(tmp3,mm)
		}
		for (k in 1:nd){
			ss1<-A1==ID_Allel[ID1[k]]
			ss2<-A2==ID_Allel[ID2[k]]
			name1<-male_name[ss1]
			name2<-female_name[ss2]
			n1<-length(name1)
			n2<-length(name2)
			mm<-NULL
			if (n1!=0 & n2!=0){
				for (k1 in 1:n1){
					for (k2 in 1:n2){
						mm<-paste(mm,paste(name1[k1],name2[k2],sep="/"),sep=",")
					}
				}
			}
			ss1<-A1==ID_Allel[ID2[k]]
			ss2<-A2==ID_Allel[ID1[k]]
			name1<-male_name[ss1]
			name2<-female_name[ss2]
			n1<-length(name1)
			n2<-length(name2)
			if (n1!=0 & n2!=0){
				for (k1 in 1:n1){
					for (k2 in 1:n2){
						mm<-paste(mm,paste(name1[k1],name2[k2],sep="/"),sep=",")
					}
				}
			}
			#mm<-substr(noquote(mm),2,nchar(mm))
			#rownames(mm)<-paste(ID_Allel[ID1[k]],ID_Allel[ID2[k]],sep="_")
			tmp3<-rbind(tmp3,mm)
		}
		Result<-rbind(Result,tmp3)
	}
	Result<-noquote(Result)
	n<-length(Result)
	for (i in 1:n){
		if (substr(Result[i],1,1)==","){
			Result[i]<-substr(Result[i],2,nchar(Result[i]))
		}
	}
	return(Result)
}

backw <- function(Indis,resp,nAllel,numvar,cc,mrk,phe,maxcomp,maxrisp,libb,el=3)
{
	# Performing backward selection
	test1=1
	crb=0
	ncp=c()
	rispmax=c()
	compmax=c()
	if (length(libb)!=0){
		while(test1==1 & crb<nrow(Indis)){
			crb=crb+1
			j=0
			test2=1
			while(test2==1 & j<nrow(libb)){
				j=j+1
				temp=Indis[crb,]==libb[j,]
				if (sum(temp)==ncol(Indis)){
					test2=0
					}
				}
			if (test2==1){
				test1=0
				}
			}
		}
	else{
		crb <- 1
		}
	
	impr <- 1
	nc <- Indis[crb,]
	if (is.null(nc)){
		nc <- Indis[1,]
		}
	startresp <- resp[crb]
	while(impr==1){
		impr <- 0
		libb <- rbind(libb,nc)
		star <- which(nc!=0)
		startvar <- length(star)
		if (startvar>1){
			for (i in 1:startvar){
				varr <- nc
				varr[star[i]] <- 0
				varr <- matrix(varr,nrow=1)
				cc <- cc+1
				if (el==3){
					varID <- matrix(as.logical(rep(varr,nAllel)),nrow=1)
					Gmrk <- mrk[,varID]
					plsobject <- plsreg_GA(Gmrk,phe,maxcomp)
					risp <- plsobject$expvarcv
					fac <- plsobject$Best
					}
				else{
					
					}
				if (risp>=startresp){
					impr <- 1
					ncp <- nc
					ncp[star[i]] <- 0
					rispmax <- risp
					compmax <- fac
					startresp <- risp
					if (risp>maxrisp){
						maxrisp <- risp
						}
					}
				}
			if (length(ncp)!=0){
				nc <- matrix(ncp,nrow=1)
				}
			}
		}
	list(nc=nc,rispmax=rispmax,compmax=compmax,cc=cc,maxrisp=maxrisp,libb=libb)
}

cross <- function(p,pcross,cmethod="uc"){

	if (cmethod=="uc"){
		diff <- which(p[1,]!=p[2,])
		randmat <- runif(length(diff))
		cro <- which(randmat<pcross)
		temp <- p[1,]
		p[1,diff[cro]] <- p[2,diff[cro]]
		p[2,diff[cro]] <- temp[diff[cro]]
		}
	else if (cmethod=="mc"){
      parents <- p
      vars <- ncol(p)
      spcvp <- runif(vars)
      scvp <- spcvp<=pcross #binary code for the crossover point,1 yes,0 no
      while (is.null(scvp)|sum(scvp)<3){
      	scvp <- spcvp<=pcross
      	}
      CrossOverPoint <- 0:vars
      CrossOverPoint <- matrix(CrossOverPoint[scvp],nrow=1)
      ncvp <- length(CrossOverPoint)
      p <- matrix(0,nrow=2,ncol=vars)
      if (CrossOverPoint[1]==0){
        if (CrossOverPoint[ncvp]==vars){
          p[id,1:CrossOverPoint[2]] <- parents[1,1:CrossOverPoint[2]]
          p[(id+1),1:CrossOverPoint[2]] <- parents[2,1:CrossOverPoint[2]]
          ncvp <- ncvp-1
          CrossOverPoint <- CrossOverPoint[-1]
          for (i in 1:(ncvp-1)){
            if (i%%2==1){
              p[id,((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <- 
                    parents[2,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              p[(id+1),((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[1,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              }
            if (i%%2==0){
              p[id,((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[1,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              p[(id+1),((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[2,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              }
            }
            id <- id+2
          }
        else {
          p[id,1:CrossOverPoint[2]] <- parents[1,1:CrossOverPoint[2]]
          p[(id+1),1:CrossOverPoint[2]] <- parents[2,1:CrossOverPoint[2]]
          CrossOverPoint <- CrossOverPoint[-1]
          CrossOverPoint <- matrix(c(CrossOverPoint,vars),nrow=1)
          for (i in 1:(ncvp-1)){
            if (i%%2==1){
              p[id,((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <- 
                    parents[2,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              p[(id+1),((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[1,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              }
            if (i%%2==0){
              p[id,((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[1,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              p[(id+1),((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[2,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              }
            }
          id <- id+2
          }
        }
      else{
        if (CrossOverPoint[ncvp]==vars){
          p[id,1:CrossOverPoint[1]] <- parents[1,1:CrossOverPoint[1]]
          p[(id+1),1:CrossOverPoint[1]] <- parents[2,1:CrossOverPoint[1]]
          for (i in 1:(ncvp-1)){
            if (i%%2==1){
              p[id,((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[2,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              p[(id+1),((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[1,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              }
            if (i%%2==0){
              p[id,((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[1,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              p[(id+1),((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[2,((CrossOverPoint[i]+1):CrossOverPoint[i+1])] 
              }
            }
          id <- id+2 
          }
        else{
          p[id,1:CrossOverPoint[1]] <- parents[1,1:CrossOverPoint[1]]
          p[(id+1),1:CrossOverPoint[1]] <- parents[2,1:CrossOverPoint[1]]
          CrossOverPoint <- matrix(c(CrossOverPoint,vars),nrow=1)
          for (i in 1:ncvp){
            if (i%%2==1){
              p[id,((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[2,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              p[(id+1),((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[1,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              }
            if (i%%2==0){
              p[id,((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[1,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              p[(id+1),((CrossOverPoint[i]+1):CrossOverPoint[i+1])] <-
                    parents[2,((CrossOverPoint[i]+1):CrossOverPoint[i+1])]
              }
            }
          id <- id+2
          }
        }
      }
	return(p)
	}

InitPopGA <- function(phe,mrk,popSize,nallel,ncomp=10)
{
	vars <- length(nallel)
	Idis <- matrix(0,nrow=popSize,ncol=vars)
	resp <- matrix(0,nrow=popSize,ncol=1)
	comp <- matrix(0,nrow=popSize,ncol=1)
	numvar <- matrix(0,nrow=popSize,ncol=1)
	lib <- matrix(0,nrow=1,ncol=vars)
	
	probsel <- 10/vars
	index <- 0
	while(index<popSize){
		den=0
		sumvar=0
		while(sumvar==0 | sumvar>0.5*vars){
			a=matrix(runif(vars),nrow=1)
			for (i in 1:vars){
				if (a[i]<probsel)
					a[i]=1
				else
					a[i]=0
				}
			sumvar=sum(a)
			}
		den=checktw(index,lib,a)
		if (den==0){
			lib <- rbind(lib,a)
			if (index==0){
				lib=lib[-1,]
				csub <- list(a=which(index==1),b=which(index==1))
				lib <- matrix(lib,nrow=1)
				}
			if (index>0){
				csub <- checksubs(index,Idis[1:index,],a)
				}
			index <- index+1
			
			temp <- rep(a,nallel)
			varID <- matrix(as.logical(temp),nrow=1)
			Gmrk <- mrk[,varID]
			plsobject <- plsreg_GA(Gmrk,phe,ncomp)
			
			if (length(csub$b)==0){
				mm=0
				}
			else {
				mm=max(resp[csub$b])
				}
			if (plsobject$expvarcv>mm){
				Idis[index,] <- a
				resp[index,1] <- plsobject$expvarcv
				comp[index,1] <- plsobject$Best
				numvar[index,1] <- sum(a)
				if (index>1 & length(csub$a)!=0){
					for (kk in 1:length(csub$a)){
						if (plsobject$expvarcv>=resp[csub$a[kk],]){
							resp[csub$a[kk],]=0
							}
						}
					}
				}
			}
		}
		
	ind <- sort(resp,index=T,decreasing = F)$ix
	Idis <- Idis[ind,]
	resp <- resp[ind,]
	comp <- comp[ind,]
	numvar <- numvar[ind,]
	list(pop=Idis,resp=resp,comp=comp,numvar=numvar,lib=lib,index=index)	
}

Loci_Sel<-function(mrkslcted,popSize){

	#mrkslcted: output of GAplsM$colsum
	#popSize: number of genetic population
	#Wang J S
	#National Center for Soybean Improvement
	#Nanjing Agriculture University
	#Nanjing, Jiangsu, China. 210095
	#July, 2012

	#Size of mrkslcted and threshold
	th<-round(popSize*0.5)
	nc<-ncol(mrkslcted)
	nr<-nrow(mrkslcted)
	
	#maximization of difference
	xx<-matrix(0,nrow=nr,ncol=nc)
	xx[mrkslcted>=th]<-1
	cs<-as.matrix(colSums(xx))
	cs<-sort(cs,decreasing=T,index=TRUE)
	dif<-cs$x[1:(nc-1)]-cs$x[2:nc]

	#The result matrix
	xx<-which(dif==max(dif))
	if (length(xx)>1){
		id<-cs$ix[1:xx[1]]
	}
	else {
		id<-cs$ix[1:xx]
	}
	tmp<-matrix(0,nrow=nc,ncol=1)
	tmp[id]<-1
	id<-tmp
	locs<-cbind(as.matrix(cs$x),as.matrix(cs$ix))
	colnames(locs)<-c("Sum","ID")
	list(id=id,locs=locs)
}

M2Dummy<-function(mrk,nullM=-9){
	# M denote molecular massre
	# 2 denote to
	# Dummy denote Dummy variable
	
	mrkname<-mrk[2:nrow(mrk),1]
	ParentIndex<-mrk[1,2:ncol(mrk)]
	mrk<-mrk[2:nrow(mrk),2:ncol(mrk)]
	nr<-nrow(mrk) # The number of markers 
	nc<-ncol(mrk)  # The number of parents
	
	result<-matrix(0,nrow=1,ncol=nc)
	mrk.name<-matrix('MRK',nrow=1,ncol=1)
	ID<-matrix(0,nrow=1,ncol=1)
	
	for (i in 1:nr){
		temp<-mrk[i,]
		m<-sort(temp,index=T)
		id<-as.vector(order(temp))
		k<-0
		mNo<-matrix(0,nrow=2,ncol=1)
		while(k<=nc){
			k<-k+1
			if (k<=nc){
				nallel<-sum(m==as.numeric(m[k]))
				if (k==1){
					mNo[1]<-m[k]
					mNo[2]<-nallel
				}
				else{
					temp<-matrix(0,nrow=2,ncol=1)
					temp[1]<-m[k]
					temp[2]<-nallel
					mNo<-cbind(mNo,temp)
				}
				k<-k-1
				k<-k+nallel
			}
		}
		mNo<-as.matrix(mNo,nrow=2)
		nc1<-ncol(mNo)
		if (as.numeric(mNo[1,1])!=nullM){
			temp<-matrix(0,nrow=nc1,ncol=nc)
		}
		else{
			temp<-matrix(0,nrow=nc1-1,ncol=nc)
		}
		k<-0
		for (i1 in 1:nc1){
			if (as.numeric(mNo[1,1])!=nullM){
				if (i1==1){
					k1<-as.numeric(mNo[2,i1])
					k0<-drop(id[(k+1):k1])
					temp[i1,k0]<-1
				}
				else{
					k<-k+as.numeric(mNo[2,i1-1])
					k1<-as.numeric(mNo[2,i1])
					k0<-drop(id[(k+1):(k+k1)])
					temp[i1,k0]<-1
				}
			}
			else{
				if (i1>1){
					k<-k+as.numeric(mNo[2,i1-1])
					k1<-as.numeric(mNo[2,i1])
					k0<-drop(id[(k+1):(k+k1)])
					temp[i1-1,k0]<-1
					#print(temp[i1-1,])
				}
			}
		}
		result<-rbind(result,temp)
		if (as.numeric(mNo[1,1])!=nullM){
			temp<-as.matrix(paste(mrkname[i],1:nc1,sep="."),ncol=1)
			tempid<-as.matrix(rep(i,nc1),ncol=1)
		}
		else{
			temp<-as.matrix(paste(mrkname[i],1:(nc1-1),sep="."),ncol=1)
			tempid<-as.matrix(rep(i,(nc1-1)),ncol=1)
		}
		mrk.name<-rbind(mrk.name,temp)
		ID<-rbind(ID,tempid)
	}
	result<-cbind(ID,result)
	rownames(result)<-mrk.name
	result<-result[-1,]
	list(mrk=result,pID=ParentIndex,mrkname=mrkname)
}

MidHeterosis<-function(phe){
	#phe: The F1 phenotype
	#The first column and the second column 
	#should be the code of parents which are used as the base of your diallel design
	
	nf1<-nrow(phe)
	MH<-matrix(0,nrow=nf1,ncol=1)
	for (i in 1:nf1){
		if (phe[i,1]==phe[i,2]){
			MH[i]<-0
		}
		else{
			MH[i]<-phe[i,3]-(phe[phe[,1]==phe[i,1]&phe[,2]==phe[i,1],3]+phe[phe[,1]==phe[i,2]&phe[,2]==phe[i,2],3])/2
		}
	}
	return(MH)
}

mutation <- function(p,pmut)
{
	vars <- ncol(p)
	m <- matrix(runif(2*vars),nrow=2)
	for (i in 1:2){
		f <- which(m[i,]<pmut)
		if (length(f)!=0){
			bb <- length(f)
			for (j in 1:bb){
				if (as.logical(p[i,f[j]])){
					p[i,f[j]]=0
					}
				else{
					p[i,f[j]]=1
					}
				}
			}
		}
	return(p)
}

ParaCol2Row<-function(x,locus,nallel,nrep){
	nlocus<-length(locus)
	re<-matrix(0,nrow=sum(nallel[locus]),ncol=nrep)
	for (i in 1:nrep){
		t0<-x[x[,1]==i,]
		id<-0
		for (j in 1:nlocus){
			id2<-t0[,2]==locus[j]
			if(sum(id2)!=0){
				t1<-t0[id2,]
				t2<-nrow(t1)
				re[((id+1):(id+t2)),i]<-t1[,3]
			}
			else{
				t2<-as.numeric(nallel[locus[j]])
				print(t2)
			}
			id<-id+t2
		}
	}
	colnames(re)<-noquote(paste("Rep",1:nrep,sep=""))	
	Locus<-rep(locus,nallel[locus])
	re<-cbind(Locus,re)
	return(re)
}

PLSest<-function(mrk,phe,ncomp=5,scale.x=FALSE,scale.y=TRUE){
	rmrk <- nrow(mrk)
	rphe <- nrow(phe)
	cmrk <- ncol(mrk)
	if(ncomp>cmrk){
		ncomp <- cmrk-2
	}
	
	ones <- matrix(1,1,rphe)
	mrk<-as.matrix(mrk)
	mu <- ones%*%phe/drop(rphe)
	phe <- scale(phe,drop(mu),FALSE)
	meanx <- drop(ones%*%mrk)/rphe
	
	mrk <- scale(mrk,meanx,FALSE)
	if (scale.x){
		normx <- sqrt(drop(ones%*%(x^2))/(rphe-1))
		if (any(normx<.Machine$double.eps)){
			{stop ("some of the colums of the predictor matrix have zero variance")}
			mrk <- scale(mrk,FALSE,normx)
			}
		else {
			normx <- rep(1,cmrk)
			}
		}
	if (scale.y){
		normy <- sqrt(drop(ones%*%(phe^2))/(rphe-1))
		if (any(normy<.Machine$double.eps)){
			stop("Some of the columns of the response matrix have zero variance")
			phe <- scale(phe,FALSE,normy)
			}
		else {
			normx <- 1
			}
		}

	#phe <- scale(phe,center=T,scale=T)
	object <- plsr(phe~mrk,ncomp=ncomp,method="simpls",validation="LOO",jackknife=TRUE,scale=FALSE)
	plot(RMSEP(object))
	jacktest<-jack.test(object)
	paraEst<-coef(object)
	rmsep<-matrix(RMSEP(object)[[1]],ncol=1)
	list(jacktest=jacktest,paraEst=paraEst,rmsep=rmsep)
}

select <- function(pop,resp)
{
	p <- matrix(0,nrow=2,ncol=ncol(pop))
	cumrisp <- as.matrix(cumsum(resp))
	nIndi <- nrow(pop)
	sresp <- matrix(0,nrow=2,ncol=1)
	if (resp[2]==0){
		rr=sample(nIndi)
		p[1,] <- pop[rr[1],]
		sresp[1] <- resp[rr[1]]
		if (resp[1]==0){
			p[2,] <- pop[rr[2],]
			sresp[2] <- resp[rr[2]]
			}
		else{
			p[2,] <- pop[1,]
			sresp[2] <- resp[rr[1]]
			}
		}
	else{
		k <- runif(1)*cumrisp[nIndi]
		j=1
		while (k>cumrisp[j]){
			j <- j+1
			}
		p[1,] <- pop[j,]
		sresp[1] <- resp[j]
		p[2,] <- p[1,]
		sresp[2] <- sresp[1]
		while(sum(p[1,]==p[2,])==ncol(pop)){
			k=runif(1)*cumrisp[nIndi]
			j=1
			while(k>cumrisp[j]){
				j=j+1
				}
			p[2,] <- pop[j,]
			sresp[2] <- sresp[j]
			}
		}
	list(parent=p,sresp=sresp)
}

SingleMrkAna<-function(phe,mrk,LocCode,Threshold=0.05){

	#phe: The F1 phenotype
	#mrk: The output of function F1Scan
	#LocCode: The output of function F1Scan
	
	#Author: Wang Jinshe
	#Institute: NCSI
	#Date:
	
	nMrk<-max(LocCode)
	phe<-matrix(phe,ncol=1)
	result<-matrix(0,nrow=1,ncol=2)
	for (i in unique(LocCode)){
		if (i%%10==0)		print(i)
		tmp<-t(mrk[LocCode==i,])
		if (ncol(tmp)!=1){
			if (ncol(tmp)<nrow(tmp)){
				lm.out<-lm(phe~tmp)
				anova.out<-anova(lm.out)
				p.out<-anova.out$Pr[1]
				if (!is.na(p.out)&p.out<=Threshold){
					result<-rbind(result,matrix(c(i,drop(p.out)),nrow=1))
				}
			}
			else{
				result<-rbind(result,matrix(c(i,0),nrow=1))
			}
		}
		else {
			cat(i,"\n")
			warning("The present marker has no polymophism, please check it!!!")
		}
	}
	result<-result[-1,]
	mrkslcted<-matrix(0,nrow=nMrk,ncol=1)
	if (length(result)>2){
	mrkslcted[result[,1]]<-1
	}
	else{
	mrkslcted[result[1]]<-1
	}
	list(locus=result,mrkslcted=mrkslcted)
}

updt <- function(Indis,popSize,sp,resp,comp,numvar,risp,fac,nvar)
{
	resp <- as.matrix(resp)
	comp <- as.matrix(comp)
	numvar <- as.matrix(numvar)
	chk <- checksubs(popSize,Indis,sp)
	s1 <- chk$a
	s2 <- chk$b
	if (length(s2)==0){
		mm=0
		}
	else {
		mm=max(resp[s2])
		}
	if (is.null(risp)){risp <- floor(mm)}
	if (risp>mm){
		resp=matrix(rbind(resp,drop(risp)),ncol=1)
		comp=rbind(comp,fac)
		Indis=rbind(Indis,sp)
		numvar=rbind(numvar,length(nvar))
		if (length(s1)!=0){
			for (kk in 1:length(s1)){
				if (risp>=resp[s1[kk]]){
					resp[s1[kk]] <- 0
					}
				}
			}
		
		index <- sort(resp,index=T,decreasing = F)$ix
		Indis <- Indis[index,]
		resp <- resp[index,]
		comp <- comp[index,]
		numvar <- numvar[index,]
		pr <- matrix(0,nrow=(popSize+1),ncol=1)
		for (ipr in 1:max(numvar)){
			prot <- which(numvar<=ipr & numvar>0)
			if (length(prot)!=0){
				pr[prot[1]]=1
				}
			}
		prot=which(pr==0)
		el=max(prot)
		Indis <- Indis[-el,]
		resp <- as.matrix(resp[-el])
		comp <- as.matrix(comp[-el])
		numvar <- as.matrix(numvar[-el])
		}
	list(Indis=Indis,resp=resp,comp=comp,numvar=numvar)
}

checktw <- function(cc,lib,a){
	den=0
	n=0
	while(den==0 & n<nrow(lib)){
		n=n+1
		index=a==lib[n,]
		index=sum(as.numeric(index))
		if (index==ncol(lib)){
			den=1
			}
		}
	return(den)
}

checksubs <- function(cr,crom,s)
{
	cmat=matrix(1,nrow=cr,ncol=1)%*%s
	d=cmat-crom
	cmat2=(d==1)
	v2=rowSums(as.matrix(cmat2))
	a=which(v2==0)
	
	cmat2=(d==-1)
	v2=rowSums(as.matrix(cmat2))
	b=which(v2==0)
	list(a=a,b=b)
}

plsreg_GA <- function(mrk,phe,ncomp=5,scale.x=FALSE,scale.y=TRUE)
{
	rmrk <- nrow(mrk)
	rphe <- nrow(phe)
	cmrk <- ncol(mrk)
	
	if(ncomp>cmrk){
		ncomp <- cmrk-2
	}
	
	ones <- matrix(1,1,rphe)
	
	mu <- ones%*%phe/rphe
	phe <- scale(phe,drop(mu),FALSE)
	meanx <- drop(ones%*%mrk)/rphe
	mrk <- scale(mrk,meanx,FALSE)
	if (scale.x){
		normx <- sqrt(drop(ones%*%(x^2))/(rphe-1))
		if (any(normx<.Machine$double.eps)){
			{stop ("some of the colums of the predictor matrix have zero variance")}
			mrk <- scale(mrk,FALSE,normx)
			}
		else {
			normx <- rep(1,cmrk)
			}
		}
	if (scale.y){
		normy <- sqrt(drop(ones%*%(phe^2))/(rphe-1))
		if (any(normy<.Machine$double.eps)){
			stop("Some of the columns of the response matrix have zero variance")
			phe <- scale(phe,FALSE,normy)
			}
		else {
			normx <- 1
			}
		}

	#phe <- scale(phe,center=T,scale=T)
	object <- plsr(phe~mrk,ncomp=ncomp,method="simpls",validation="LOO",scale=F)
	expvar <- as.matrix(explvar(object))
	
	dif<-expvar[1:(ncomp-1)]-expvar[2:ncomp]
	kk<-which(dif<0)
	if (length(kk)==0){
		best<-ncomp
	}
	else{
		best<-kk[1]
	}
	res<-residuals(object)[,,best]
	exp_var_cv<-sqrt(sum(res^2)/rphe)
	if (is.na(exp_var_cv)){
		best<-1
		exp_var_cv<-drop(var(phe))
	}
	list(Best=best,expvarcv=exp_var_cv)
}
